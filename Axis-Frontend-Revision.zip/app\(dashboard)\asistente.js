import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { useAuth, useUser } from '../../src/shared/hooks/useClerkOrMock';
import { colors } from '../../src/shared/theme/colors';
import AsistenteIAScreen from '../../src/modules/docente/presentation/screens/AsistenteIAScreen';

export default function AsistenteRoute() {
  const { getToken } = useAuth();
  const { user } = useUser();
  const [token, setToken] = useState(null);

  const rol = user?.publicMetadata?.rol?.toLowerCase() || 'estudiante';

  useEffect(() => {
    let activo = true;
    getToken().then((t) => activo && setToken(t));
    return () => { activo = false; };
  }, [getToken]);

  if (!token) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  // onBack = undefined → componente mostrará AppHeader normal (modo tab)
  // onVerReportes navega al tab de reportes
  return (
    <AsistenteIAScreen
      token={token}
      rol={rol}
      onVerReportes={undefined}
    />
  );
}
