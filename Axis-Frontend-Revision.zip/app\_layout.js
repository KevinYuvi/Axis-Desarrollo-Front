import { useEffect } from 'react';
import { Slot, useRouter, useSegments } from 'expo-router';
import { ClerkProvider } from '@clerk/clerk-expo';
import { useAuth, useUser } from '../src/shared/hooks/useClerkOrMock';
import { Text, View } from 'react-native';
import { tokenCache } from '../utils/tokenCache';

const RAW_CLERK_KEY = process.env.EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY;
const CLERK_PUBLISHABLE_KEY = RAW_CLERK_KEY?.trim()?.replace(/^['"]|['"]$/g, '');
const HAS_VALID_CLERK_KEY = !!CLERK_PUBLISHABLE_KEY && CLERK_PUBLISHABLE_KEY.startsWith('pk_');

const InitialLayout = () => {
  const { isLoaded, isSignedIn } = useAuth();
  const { user } = useUser();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    // Si Clerk aún no termina de cargar la información, no hacemos nada
    if (!isLoaded) return;

    // Verificamos en qué grupo de pantallas está el usuario
    const inDashboardGroup = segments[0] === '(dashboard)';
    const inAuthGroup = segments[0] === '(auth)';

    if (isSignedIn && !inDashboardGroup) {
      // Con sesión activa, el admin va a su panel, el resto al index que es un enrutador inteligente
      const rol = user?.publicMetadata?.rol?.toLowerCase() ?? 'estudiante';
      if (rol === 'admin') {
        router.replace('/(dashboard)/admin');
      } else {
        router.replace('/(dashboard)');
      }
    } else if (!isSignedIn && !inAuthGroup) {
      router.replace('/(auth)/login');
    }
  }, [isSignedIn, isLoaded, segments, user]);

  return <Slot />;
};

export default function RootLayout() {
  if (!HAS_VALID_CLERK_KEY) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#FAFAFA' }}>
        <Text style={{ color: '#EF4444', fontWeight: 'bold', fontSize: 18, textAlign: 'center', padding: 20 }}>
          Error CRÍTICO: EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY no existe o es inválida.
        </Text>
      </View>
    );
  }

  return (
    <ClerkProvider publishableKey={CLERK_PUBLISHABLE_KEY} tokenCache={tokenCache}>
      <InitialLayout />
    </ClerkProvider>
  );
}